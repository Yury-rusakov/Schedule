import React, { useState, useEffect } from 'react';
import { IntlProvider, FormattedMessage, useIntl } from 'react-intl';
import en from './locales/en.json';
import ru from './locales/ru.json';
import LanguageSwitcher from './components/LanguageSwitcher';

const messages = {
  'en': en,
  'ru': ru,
};

function App() {
  const [locale, setLocale] = useState(() => {
    const storedLocale = localStorage.getItem('locale');
    return storedLocale || 'en';
  });
  const [currentMessages, setCurrentMessages] = useState(messages[locale]);

  useEffect(() => {
    setCurrentMessages(messages[locale]);
  }, [locale]);


  useEffect(() => {
    localStorage.setItem('locale', locale);
  }, [locale]);


  return (
    <IntlProvider locale={locale} messages={currentMessages}>
      <div className="App">
        <LanguageSwitcher setLocale={setLocale} />
        <Menu />
        <h1><FormattedMessage id="menu.home" /></h1>
        <p><FormattedMessage id="menu.about" /></p>
      </div>
    </IntlProvider>
  );
}


export default App;
