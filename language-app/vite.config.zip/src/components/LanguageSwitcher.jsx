import React from 'react';
import { FormattedMessage } from 'react-intl';

function LanguageSwitcher({ setLocale }) {
  const handleLanguageChange = (event) => {
    setLocale(event.target.value);
  };

  return (
    <div>
      <label htmlFor="language">
        <FormattedMessage id="language.select" defaultMessage="Select Language:" />
      </label>
      <select id="language" onChange={handleLanguageChange}>
        <option value="en">English</option>
        <option value="ru">Русский</option>
      </select>
    </div>
  );
}

export default LanguageSwitcher;
