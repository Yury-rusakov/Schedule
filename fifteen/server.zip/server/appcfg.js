export const params = {
    Project_Root: '../dist/',
    mysql_cfg:{
      host: 'localhost', 
      user: 'User1',
      password: 'qwerty123',
      database: 'MyBase',
      connectionLimit: 5
    }
};